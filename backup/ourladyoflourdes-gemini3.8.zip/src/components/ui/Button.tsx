import React from "react";
import { Link } from "react-router-dom";
import { cn } from "@/utils/cn";

export type ButtonVariant = "primary" | "secondary" | "ghost" | "outline-light";
export type ButtonSize = "sm" | "md" | "lg";

export interface ButtonBaseProps {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: React.ReactNode;
  iconPosition?: "left" | "right";
  className?: string;
  children: React.ReactNode;
}

export type ButtonProps =
  | (ButtonBaseProps & { to: string; href?: never } & Omit<React.ComponentProps<typeof Link>, "to" | "className">)
  | (ButtonBaseProps & { href: string; to?: never } & React.AnchorHTMLAttributes<HTMLAnchorElement>)
  | (ButtonBaseProps & { to?: never; href?: never } & React.ButtonHTMLAttributes<HTMLButtonElement>);

const variantClasses: Record<ButtonVariant, string> = {
  primary:
    "bg-olol-gold-500 hover:bg-olol-gold-600 text-olol-sapphire-950 font-semibold shadow-sm hover:shadow active:scale-[0.98] border border-olol-gold-400",
  secondary:
    "bg-olol-sapphire-700 hover:bg-olol-sapphire-800 text-white font-semibold shadow-sm active:scale-[0.98] border border-olol-sapphire-600",
  ghost:
    "bg-transparent hover:bg-olol-parchment text-olol-ink font-semibold active:scale-[0.98] border border-transparent",
  "outline-light":
    "bg-transparent hover:bg-white/10 text-white font-semibold border border-white/30 hover:border-white/60 active:scale-[0.98]",
};

const sizeClasses: Record<ButtonSize, string> = {
  sm: "px-3.5 py-1.5 text-xs rounded-sm gap-1.5",
  md: "px-5 py-2.5 text-sm rounded-[3px] gap-2",
  lg: "px-7 py-3.5 text-base rounded-[4px] gap-2.5",
};

export function Button({
  variant = "primary",
  size = "md",
  icon,
  iconPosition = "right",
  className,
  children,
  ...rest
}: ButtonProps) {
  const baseClasses = cn(
    "inline-flex items-center justify-center font-medium transition-all duration-200 cursor-pointer text-center select-none",
    variantClasses[variant],
    sizeClasses[size],
    className
  );

  const content = (
    <>
      {icon && iconPosition === "left" && (
        <span className="inline-flex shrink-0 transition-transform duration-200 group-hover:-translate-x-0.5" aria-hidden="true">
          {icon}
        </span>
      )}
      <span>{children}</span>
      {icon && iconPosition === "right" && (
        <span className="inline-flex shrink-0 transition-transform duration-200 group-hover:translate-x-0.5" aria-hidden="true">
          {icon}
        </span>
      )}
    </>
  );

  if ("to" in rest && rest.to) {
    const { to, ...routerLinkProps } = rest as { to: string } & React.ComponentProps<typeof Link>;
    return (
      <Link to={to} className={baseClasses} {...routerLinkProps}>
        {content}
      </Link>
    );
  }

  if ("href" in rest && rest.href) {
    const { href, ...anchorProps } = rest as { href: string } & React.AnchorHTMLAttributes<HTMLAnchorElement>;
    return (
      <a href={href} className={baseClasses} {...anchorProps}>
        {content}
      </a>
    );
  }

  const buttonProps = rest as React.ButtonHTMLAttributes<HTMLButtonElement>;
  return (
    <button type="button" className={baseClasses} {...buttonProps}>
      {content}
    </button>
  );
}
