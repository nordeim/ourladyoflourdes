import React, { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/utils/cn";

export interface AccordionItemData {
  id?: string;
  title: string;
  content: React.ReactNode;
  badge?: string;
}

export interface AccordionProps {
  items: AccordionItemData[];
  className?: string;
  defaultOpenIndex?: number;
}

export function Accordion({ items, className, defaultOpenIndex }: AccordionProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(defaultOpenIndex ?? null);

  const toggle = (index: number) => {
    setOpenIndex((current) => (current === index ? null : index));
  };

  return (
    <div className={cn("space-y-3", className)}>
      {items.map((item, index) => {
        const isOpen = openIndex === index;
        const panelId = `accordion-panel-${index}`;
        const buttonId = `accordion-button-${index}`;

        return (
          <div
            key={item.id ?? index}
            className={cn(
              "border rounded-[3px] transition-colors duration-200 overflow-hidden",
              isOpen
                ? "bg-white border-olol-gold-400 shadow-sm"
                : "bg-olol-cream/80 border-olol-stone/70 hover:border-olol-gold-300"
            )}
          >
            <button
              id={buttonId}
              type="button"
              aria-expanded={isOpen}
              aria-controls={panelId}
              onClick={() => toggle(index)}
              className="w-full flex items-center justify-between p-4 sm:p-5 text-left text-base sm:text-lg font-display font-medium text-olol-sapphire-950 focus:outline-none focus-visible:ring-2 focus-visible:ring-olol-gold-400"
            >
              <div className="flex items-center gap-3 pr-4">
                <span>{item.title}</span>
                {item.badge && (
                  <span className="text-[11px] font-sans font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-olol-gold-100 text-olol-gold-700 border border-olol-gold-300/60">
                    {item.badge}
                  </span>
                )}
              </div>
              <ChevronDown
                className={cn(
                  "w-5 h-5 shrink-0 text-olol-gold-600 transition-transform duration-200",
                  isOpen && "rotate-180"
                )}
                aria-hidden="true"
              />
            </button>

            <div
              id={panelId}
              role="region"
              aria-labelledby={buttonId}
              className={cn(
                "grid transition-all duration-300 ease-in-out",
                isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
              )}
            >
              <div className="overflow-hidden">
                <div className="px-4 pb-5 sm:px-5 sm:pb-6 pt-1 text-sm sm:text-base leading-relaxed text-olol-charcoal border-t border-olol-stone/30">
                  {item.content}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
