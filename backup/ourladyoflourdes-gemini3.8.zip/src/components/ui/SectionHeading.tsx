import { cn } from "@/utils/cn";

export interface SectionHeadingProps {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  light?: boolean;
  className?: string;
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "center",
  light = false,
  className,
}: SectionHeadingProps) {
  const isCenter = align === "center";

  return (
    <div className={cn("mb-10 md:mb-14", isCenter ? "text-center mx-auto max-w-3xl" : "text-left max-w-2xl", className)}>
      {eyebrow && (
        <div
          className={cn(
            "text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-2",
            light ? "text-olol-gold-300" : "text-olol-gold-700"
          )}
        >
          {eyebrow}
        </div>
      )}

      <h2
        className={cn(
          "font-display text-3xl sm:text-4xl lg:text-5xl font-normal tracking-tight text-balance",
          light ? "text-white" : "text-olol-sapphire-950"
        )}
      >
        {title}
      </h2>

      {/* Liturgical Rule Line */}
      <div
        className={cn(
          "my-4 h-px",
          isCenter
            ? "mx-auto w-32 bg-gradient-to-r from-transparent via-olol-gold-400 to-transparent"
            : "w-24 bg-gradient-to-r from-olol-gold-400 to-transparent"
        )}
        aria-hidden="true"
      />

      {description && (
        <p
          className={cn(
            "text-base sm:text-lg leading-relaxed text-balance",
            light ? "text-white/80" : "text-olol-charcoal"
          )}
        >
          {description}
        </p>
      )}
    </div>
  );
}
