import { cn } from "@/utils/cn";

export interface EmblemProps {
  className?: string;
  size?: number;
  light?: boolean;
}

export function Emblem({ className, size = 64, light = false }: EmblemProps) {
  const strokeColor = light ? "#e2ba52" : "#b08123";
  const accentColor = light ? "#ffffff" : "#0a1b38";
  const waterColor = light ? "#7ed0df" : "#1c7e93";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 80 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0 select-none", className)}
      aria-hidden="true"
    >
      {/* Outer Gothic Arch Frame */}
      <path
        d="M40 8 C25 22, 16 38, 16 62 C16 70, 22 72, 40 72 C58 72, 64 70, 64 62 C64 38, 55 22, 40 8 Z"
        stroke={strokeColor}
        strokeWidth="2"
        fill="none"
      />
      <path
        d="M40 14 C28 26, 21 40, 21 60 C21 66, 26 67, 40 67 C54 67, 59 66, 59 60 C59 40, 52 26, 40 14 Z"
        stroke={strokeColor}
        strokeWidth="1"
        strokeDasharray="2 3"
        fill="none"
      />

      {/* Gothic Cross finial atop */}
      <line x1="40" y1="4" x2="40" y2="15" stroke={strokeColor} strokeWidth="2.2" strokeLinecap="round" />
      <line x1="34" y1="8" x2="46" y2="8" stroke={strokeColor} strokeWidth="2.2" strokeLinecap="round" />

      {/* Marian Monogram 'M' */}
      <path
        d="M27 54 L33 30 L40 44 L47 30 L53 54"
        stroke={accentColor}
        strokeWidth="2.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Lourdes Crown of 12 Stars (represented by 5 prominent celestial points) */}
      <circle cx="40" cy="24" r="2.2" fill={strokeColor} />
      <circle cx="32" cy="26" r="1.8" fill={strokeColor} />
      <circle cx="48" cy="26" r="1.8" fill={strokeColor} />
      <circle cx="26" cy="31" r="1.5" fill={strokeColor} />
      <circle cx="54" cy="31" r="1.5" fill={strokeColor} />

      {/* Miraculous Spring ripples */}
      <path
        d="M24 62 Q32 58 40 62 T56 62"
        stroke={waterColor}
        strokeWidth="1.8"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}
