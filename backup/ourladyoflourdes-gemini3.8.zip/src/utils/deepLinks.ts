export const knownRoutePaths = [
  "/",
  "/about",
  "/history",
  "/worship",
  "/mass-times",
  "/hours-location",
  "/visit",
  "/ministries",
  "/ministry",
  "/news-events",
  "/news-and-events",
  "/serve",
  "/volunteer",
  "/give",
  "/donate",
  "/faq",
] as const;

export function resolveHashRedirect(): void {
  if (typeof window === "undefined") return;

  const pathname = window.location.pathname;
  if (pathname !== "/" && !window.location.hash) {
    const isKnown = knownRoutePaths.some((p) => p === pathname || pathname.startsWith(p + "/"));
    if (isKnown) {
      window.location.replace(`/#${pathname}${window.location.search}`);
    }
  }
}
