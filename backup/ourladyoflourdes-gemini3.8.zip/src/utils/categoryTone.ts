export interface CategoryToneStyle {
  bg: string;
  text: string;
  border: string;
}

export function categoryTone(category: string): CategoryToneStyle {
  switch (category.toLowerCase()) {
    case "feast":
      return {
        bg: "bg-olol-gold-100",
        text: "text-olol-gold-700",
        border: "border-olol-gold-400",
      };
    case "devotion":
      return {
        bg: "bg-olol-sapphire-50",
        text: "text-olol-sapphire-700",
        border: "border-olol-sapphire-300",
      };
    case "formation":
      return {
        bg: "bg-olol-spring-50",
        text: "text-olol-spring-600",
        border: "border-olol-spring-300",
      };
    case "parish":
    default:
      return {
        bg: "bg-olol-rose-50",
        text: "text-olol-rose-600",
        border: "border-olol-rose-300",
      };
  }
}
