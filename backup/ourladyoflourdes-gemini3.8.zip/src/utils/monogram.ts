export function monogram(name: string): string {
  if (!name) return "";

  // Strip prefixes & suffixes like Rev., Fr., HGN, MEP, SS.CC, etc.
  const cleaned = name
    .replace(/\b(rev|reverend|fr|father|friar|msgr|monsignor|deacon|dr|mr|mrs|ms|hgn|mep|ss\.cc|sscc|ofm)\b/gi, "")
    .replace(/[.,]/g, "")
    .trim();

  const parts = cleaned.split(/\s+/).filter(Boolean);
  if (parts.length === 0) return name.slice(0, 2).toUpperCase();
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
