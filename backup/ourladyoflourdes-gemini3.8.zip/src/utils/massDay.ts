export type MassDayKey = "weekdays" | "saturday" | "sunday";

export function massDayKey(date: Date = new Date()): MassDayKey {
  const day = date.getDay();
  switch (day) {
    case 0:
      return "sunday";
    case 6:
      return "saturday";
    default:
      return "weekdays";
  }
}
