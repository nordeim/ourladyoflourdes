export const site = {
  name: "Church of Our Lady of Lourdes",
  shortName: "Our Lady of Lourdes",
  nativeName: "தூய லூர்து அன்னை ஆலயம்",
  tagline: "A Sanctuary of Grace, Healing & Fellowship",
  taglineSecondary: "Faith · Healing · Community · Since 1888",
  vision:
    "To be a vibrant Eucharistic household of faith, hope, and charity, drawing all people into Christ's healing love through the maternal intercession of Our Lady of Lourdes.",
  mission:
    "Rooted in the Gospel and the Catholic tradition, we welcome every soul to experience God's mercy at the altar, accompany the sick and marginalized, and build a united multilingual family of faith in the heart of Singapore.",
  heritage:
    "Modelled after the Basilica of the Immaculate Conception in Lourdes, France. Built in 1888 by Fr. Joachim Meneuvrier, MEP. Gazetted as a National Monument of Singapore on 14 January 2005.",
  foundedYear: 1888,
  nationalMonumentDate: "14 January 2005",

  address: {
    street: "50 Ophir Road",
    city: "Singapore",
    zip: "188690",
    district: "Rochor / Bugis, City District",
    full: "50 Ophir Road, Singapore 188690",
    query: "50+Ophir+Road,+Singapore+188690",
  },

  hours: {
    church: "Daily 7:00 AM – 9:00 PM",
    office: "Monday to Friday: 9:00 AM – 6:00 PM (Closed on Public Holidays)",
    reception: "Monday to Friday: 9:00 AM – 6:00 PM",
    adoration: "Daily 8:00 AM – 8:00 PM (Adoration Room)",
    confessionWeekday: "15 mins before 12:30 PM & 7:00 PM Masses",
    confessionWeekend: "15 mins before all Saturday & Sunday Masses",
  },

  mass: {
    weekdayMorning: "12:30 PM (English, Mon–Fri in Main Church)",
    weekdayEvening: "7:00 PM (Tamil, Mon–Fri in Main Church)",
    weekdayDevotions: [
      { day: "Mon, Wed, Thu, Fri", time: "11:35 AM", title: "Holy Rosary" },
      { day: "Tuesday", time: "11:35 AM", title: "Divine Mercy Chaplet" },
    ],
    saturday: [
      { time: "5:00 PM", language: "English", venue: "Main Church" },
      { time: "6:15 PM", language: "English", venue: "Main Church" },
      { time: "7:30 PM", language: "English", venue: "Main Church" },
    ],
    saturdayDevotions: [
      { time: "4:15 PM", title: "Holy Rosary", language: "English", venue: "Main Church" },
      { time: "5:30 PM", title: "Novena to Our Lady of Lourdes", language: "English", venue: "Main Church" },
      { time: "8:30 PM", title: "Novena to OLPS", language: "Tamil", venue: "St. Bernadette Hall" },
    ],
    sunday: [
      { time: "8:00 AM", language: "English", venue: "Main Church" },
      { time: "9:30 AM", language: "Tamil", venue: "Main Church" },
      { time: "11:00 AM", language: "English", venue: "Main Church" },
      { time: "12:30 PM", language: "English", venue: "Main Church" },
      { time: "6:30 PM", language: "Tamil", venue: "Main Church" },
    ],
    specialMasses: [
      {
        cadence: "1st Sunday of every month",
        time: "12:30 PM",
        language: "Sinhala",
        community: "Sri Lankan Community",
        venue: "Sri Lankan Hall / Main Church",
      },
      {
        cadence: "2nd Saturday of every month",
        time: "9:00 PM – Dawn",
        language: "Tamil",
        community: "Tamil Community",
        venue: "Monthly All-Night Eucharistic Vigil",
      },
    ],
    publicHolidays: "9:00 AM (English) · 10:00 AM (Tamil)",
    confession: "Sacrament of Reconciliation available 15 minutes before every Mass and upon request at the Parish Office.",
    adoration: "Adoration Room open daily 8:00 AM – 8:00 PM for private prayer in the presence of the Blessed Sacrament.",
    note: "Public Holiday notice: The Parish Office is closed on gazetted public holidays, and main church gates close at 5:00 PM after holiday services.",
  },

  contact: {
    phone: "+65 6294 0624",
    fax: "+65 6294 2686",
    email: "colol.secretariat@catholic.org.sg",
    hallBookingEmail: "colol.mtn@catholic.org.sg",
    rciaCoordinator: "Sarah (+65 9674 5600)",
    catechismCoordinator: "Verna (+65 9457 0191)",
    bereavementCoordinator: "Parish Office (+65 6294 0624)",
    migrantWelfare: "Rev. Fr. Leo Justin, HGN (+65 6294 0624)",
  },

  transport: {
    mrt: "Bugis (EW12 / DT14, 5-min walk via Exit A or B) · Rochor (DT13, 6-min walk) · Jalan Besar (DT22, 7-min walk)",
    buses: "Buses along Ophir Road (Stop 07589) & Victoria Street: 48, 57, 130, 851, 960, 2, 12, 33, 133",
    parking:
      "Limited parking spaces available within the church compound on a first-come, first-served basis. Ample public parking is situated nearby at Fu Lu Shou Complex, Albert Centre multi-storey carpark, and Bugis Junction.",
  },

  feast: {
    name: "Feast of Our Lady of Lourdes & World Day of the Sick",
    date: "11 February",
    secondary: [
      { name: "Feast of Our Lady of Vailankanni", date: "September (9 Weeks Novena)" },
      { name: "Pongal Thanksgiving Harvest Festival", date: "14 January" },
      { name: "Memorial of St. Bernadette Soubirous", date: "16 April" },
      { name: "Solemnity of the Assumption of the Blessed Virgin Mary", date: "15 August" },
    ],
  },

  giving: {
    uen: "T08CC4026D",
    entityName: "Church of Our Lady of Lourdes",
    chequePayee: "Church of Our Lady of Lourdes",
    payNowDescription: "Select PayNow by UEN: T08CC4026D in your banking app. Ensure the payee displays Church of Our Lady of Lourdes.",
  },

  socials: {
    facebook: "https://www.facebook.com/ChurchOfOurLadyOfLourdes/",
    instagram: "https://www.instagram.com/olol_sg/",
    youtube: "https://www.youtube.com/@ChurchOfOurLadyOfLourdesSG",
    archdiocese: "https://www.catholic.sg",
  },

  mapsUrl: "https://maps.google.com/?q=Church+of+Our+Lady+of+Lourdes+50+Ophir+Road+Singapore+188690",
  mapsEmbedSrc: "https://www.google.com/maps?q=50+Ophir+Road,+Singapore+188690&output=embed",
} as const;
