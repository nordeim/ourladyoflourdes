export interface NavChild {
  label: string;
  to: string;
  description: string;
}

export interface NavItem {
  label: string;
  to: string;
  children?: NavChild[];
}

export interface NavLink {
  label: string;
  to: string;
}

export const primaryNav: NavItem[] = [
  {
    label: "Home",
    to: "/",
  },
  {
    label: "About",
    to: "/about",
    children: [
      {
        label: "The Parish",
        to: "/about",
        description: "Our mission, clergy, and parish community at Ophir Road.",
      },
      {
        label: "Our History",
        to: "/history",
        description: "1888 French Gothic origins, National Monument status, and restoration.",
      },
      {
        label: "FAQ & Visiting",
        to: "/faq",
        description: "Dresscode guidelines, Mass tongues, confessions, and weddings.",
      },
    ],
  },
  {
    label: "Worship",
    to: "/worship",
    children: [
      {
        label: "Mass Times",
        to: "/worship#mass",
        description: "Daily English and Tamil Masses, weekend sunset and Sunday schedules.",
      },
      {
        label: "Grotto, Adoration & Mercy",
        to: "/worship#confession",
        description: "Massabielle Grotto replica, daily Adoration room, and Reconciliation.",
      },
      {
        label: "Find Us",
        to: "/worship#visit",
        description: "50 Ophir Road location, Bugis/Rochor MRT access, and carpark guide.",
      },
    ],
  },
  {
    label: "Ministries",
    to: "/ministries",
    children: [
      {
        label: "Liturgical Ministries",
        to: "/ministries#liturgical",
        description: "Altar servers, lectors, music ministries, and EMHC.",
      },
      {
        label: "Faith Formation & RCIA",
        to: "/ministries#faith-formation",
        description: "Rite of Christian Initiation for Adults and Saturday catechism.",
      },
      {
        label: "Outreach & Migrant Care",
        to: "/ministries#outreach",
        description: "Agape Migrant Welfare Committee, SSVP, and Bereavement ministry.",
      },
    ],
  },
  {
    label: "News & Events",
    to: "/news-events",
  },
  {
    label: "Serve",
    to: "/serve",
  },
];

export const footerNav: NavLink[] = [
  { label: "Home", to: "/" },
  { label: "About Our Parish", to: "/about" },
  { label: "1888 Heritage & History", to: "/history" },
  { label: "Mass & Confession Schedule", to: "/worship" },
  { label: "Ministries & Community", to: "/ministries" },
  { label: "News & Events", to: "/news-events" },
  { label: "Serve & Volunteer", to: "/serve" },
  { label: "Stewardship & Giving", to: "/give" },
  { label: "Visitor FAQ & Guidelines", to: "/faq" },
  { label: "Holy Matrimony & Sacraments", to: "/faq#sacraments" },
];
