export interface TimelineEntry {
  year: string;
  title: string;
  summary: string;
  detail: string;
}

export interface GroundsPlace {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  image: string;
  imageFallback: string;
  imageAlt: string;
  highlights: string[];
}

export interface MinistryGroup {
  id: string;
  title: string;
  tagline: string;
  description: string;
  coordinator?: string;
  meetingTime?: string;
  duties: string[];
  contactEmail?: string;
}

export interface Ministry {
  id: string;
  title: string;
  summary: string;
  image: string;
  imageAlt: string;
  groups: MinistryGroup[];
}

export interface FaqItem {
  question: string;
  answer: string;
  category: "Visiting" | "Liturgical" | "Sacraments" | "Community";
}

export interface EventItem {
  id: string;
  title: string;
  date: string;
  time: string;
  summary: string;
  category: "Parish" | "Devotion" | "Formation" | "Feast";
  venue: string;
  featured?: boolean;
}

export interface GivingOption {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  method: string;
  details: string;
  icon: "globe" | "church" | "book" | "heart" | "flame" | "sprout";
  tag?: string;
}

export interface Priest {
  name: string;
  title: string;
  role: string;
  bio: string;
  email?: string;
  appointed?: string;
  tenure?: string;
  isHistorical?: boolean;
}

export interface PpcMember {
  name: string;
  role: string;
  responsibility: string;
}

export interface ServeRole {
  title: string;
  team: string;
  summary: string;
  commitment: string;
  requirements: string;
}

export interface Devotion {
  title: string;
  when: string;
  where: string;
  language: string;
  description: string;
}

export const priests: Priest[] = [
  {
    name: "Rev. Fr. Alphonsus Dominic",
    title: "Rev. Fr.",
    role: "Parish Priest",
    bio: "Appointed Parish Priest of Church of Our Lady of Lourdes in 2026. Leads the parish pastoral vision, community spiritual renewal, and pastoral care across our multilingual household.",
    email: "colol.secretariat@catholic.org.sg",
    appointed: "2026",
    tenure: "Present",
  },
  {
    name: "Rev. Fr. Leo Justin, HGN",
    title: "Rev. Fr.",
    role: "Assistant Parish Priest",
    bio: "Heralds of Good News (HGN). Serves the pastoral and liturgical life of the parish with dedicated oversight of the Tamil congregation, youth formation, and the Agape Migrant Welfare Committee.",
    email: "colol.secretariat@catholic.org.sg",
    appointed: "2021",
    tenure: "Present",
  },
  {
    name: "Rev. Fr. Michael Sitaram",
    title: "Rev. Fr.",
    role: "Priest in Residence / Former Parish Priest",
    bio: "Served as Parish Priest from 2017 to 2026, spearheading the monumental $6.5 million restoration of the historic neo-Gothic sanctuary, stained-glass windows, and liturgical rejuvenation.",
    appointed: "2017",
    tenure: "2017 – 2026",
  },
  {
    name: "Rev. Fr. Joachim Alexandre Marie Meneuvrier, MEP",
    title: "Rev. Fr.",
    role: "Founding Missionary & Architect (1884–1898)",
    bio: "French MEP missionary tasked by Bishop Gasnier to master Tamil and build a dedicated church for Indian Catholics in Singapore. Modelled the church after Lourdes, France, laying the cornerstone on 1 August 1886 and dedicating it in 1888.",
    tenure: "1884 – 1898",
    isHistorical: true,
  },
  {
    name: "Rev. Fr. Louis Burghoffer, MEP",
    title: "Rev. Fr.",
    role: "Pioneer Pastor (1898–1932)",
    bio: "Devoted 34 remarkable years of pastoral service to the Tamil Catholic flock and school. Remembered with Fr. Meneuvrier by historical brass tablets inside the sanctuary.",
    tenure: "1898 – 1932",
    isHistorical: true,
  },
  {
    name: "Rev. Fr. Ignatius John Aloysius",
    title: "Rev. Fr.",
    role: "First Local & Indian Parish Priest (1947–1955)",
    bio: "First local and Indian priest appointed to head the parish, succeeding Msgr. Michel Olçomendy. Later became Vicar-General and was created Honorary Prelate by Pope Paul VI.",
    tenure: "1947 – 1955",
    isHistorical: true,
  },
];

export const ppcMembers: PpcMember[] = [
  {
    name: "Rev. Fr. Alphonsus Dominic",
    role: "President (Ex-Officio)",
    responsibility: "Parish spiritual oversight, liturgical direction, and administration",
  },
  {
    name: "Rev. Fr. Leo Justin, HGN",
    role: "Spiritual Director (Ex-Officio)",
    responsibility: "Tamil apostolate, migrant welfare, and youth formation",
  },
  {
    name: "Juliana Francis",
    role: "Pastoral Coordinator & Secretariat",
    responsibility: "Parish pastoral administration, communication, and scheduling",
  },
  {
    name: "Kelvin Tan",
    role: "Head of Finance & Operations",
    responsibility: "Parish financial stewardship, building maintenance, and audit compliance",
  },
  {
    name: "Verna De Souza",
    role: "Catechetical Coordinator",
    responsibility: "Children and youth sacramental preparation and catechist development",
  },
  {
    name: "Sarah Gnanam",
    role: "RCIA Lead Coordinator",
    responsibility: "Adult initiation journey, sponsor pairing, and Easter Vigil sacraments",
  },
];

export const lifeTimeline: TimelineEntry[] = [
  {
    year: "1858–1884",
    title: "Early Seeds at Mission Ground",
    summary: "Tamil Catholic community ministers from Church of Sts. Peter & Paul under Fr. Pierre Paris.",
    detail:
      "Indian Catholics arrived in Singapore as early as 1821. Fr. Pierre Paris, fluent in Tamil, celebrated Mass, taught catechism, and provided schooling. As the community flourished, the need for a dedicated Indian parish became urgent.",
  },
  {
    year: "1884–1886",
    title: "Fr. Joachim Meneuvrier & Land at Ophir Road",
    summary: "Land granted along Rochor Canal; cornerstone blessed on 1 August 1886.",
    detail:
      "Bishop Édouard Gasnier tasked Fr. Joachim Alexandre Marie Meneuvrier, MEP, with learning Tamil and founding the parish. After two petitions, Straits Settlements Governor Sir Cecil Clementi Smith granted a plot in Ophir Road.",
  },
  {
    year: "1888",
    title: "Consecration of the French Gothic Sanctuary",
    summary: "The church opens in May 1888, modelled after the Basilica at Lourdes in France.",
    detail:
      "Crafted with 16 slender Parisian cast-iron columns, soaring lancet windows, flying buttresses, and a replica Grotto of Massabielle, the church became the Mother Church for Tamil Catholics in Singapore and southern Johor.",
  },
  {
    year: "1942–1945",
    title: "Miraculous Survival during World War II",
    summary: "Two air bombs hit the compound; the sanctuary emerges completely intact.",
    detail:
      "During the Japanese invasion, two bombs hit the presbytery and school, blowing off the upper floor. Miraculously, the main sanctuary stood unharmed. It briefly housed Japanese headquarters before being reclaimed for worship.",
  },
  {
    year: "1958–1959",
    title: "Centenary of Lourdes & The 15 Rosary Windows",
    summary: "Restoration of the French stained-glass windows and installation of Ave Maria chimes.",
    detail:
      "Marking 100 years of the Marian apparitions in Lourdes, Fr. Albert Fortier commissioned French master craftsmen to restore the 15 clerestory stained-glass windows depicting the mysteries of the Holy Rosary, and installed chime bells playing Ave Maria.",
  },
  {
    year: "1974",
    title: "Evolution to a Territorial Parish",
    summary: "Diocesan realignment welcomes Catholics of all backgrounds in the City District.",
    detail:
      "The Archdiocese transitioned parishes from purely ethnic communities to territorial jurisdictions. Our Lady of Lourdes opened its doors to English, Tamil, and regional migrants across Rochor, Bugis, and central Singapore.",
  },
  {
    year: "2005",
    title: "Gazetted as a National Monument of Singapore",
    summary: "Preservation of Monuments Board grants Singapore's highest heritage status on 14 January 2005.",
    detail:
      "Recognized for its unique architectural pedigree as an early neo-Gothic sanctuary with French prefabricated iron elements, historic social impact, and enduring community role, the church was protected as a National Monument.",
  },
  {
    year: "2021–2024",
    title: "$6.5M Comprehensive Restoration & Reopening",
    summary: "Major multi-year structural and aesthetic conservation preserves the sanctuary for generations.",
    detail:
      "Under Fr. Michael Sitaram and heritage specialists, the church completed an extensive $6.5 million restoration of its delicate spire, timber roof trusses, historic French stained glass, and liturgical acoustics, reopening for radiant worship.",
  },
];

export const grounds: GroundsPlace[] = [
  {
    id: "main-sanctuary",
    name: "The Main Sanctuary & Nave",
    subtitle: "French Neo-Gothic Elegance",
    description:
      "The high vaulted nave features 16 slender cast-iron columns imported from Paris, allowing an airy, open column spacing. The rounded apse frames the holy altar where a first-class relic of St. Bernadette is inset.",
    image: "/images/sanctuary.jpg",
    imageFallback: "/images/hero-church.jpg",
    imageAlt: "Interior nave of Church of Our Lady of Lourdes with cast-iron columns and altar",
    highlights: ["16 Parisian cast-iron columns", "St. Bernadette altar relic", "Curved circular apse & crucifix"],
  },
  {
    id: "grotto-massabielle",
    name: "Grotto of Our Lady of Lourdes",
    subtitle: "Replica of the Massabielle Grotto",
    description:
      "Nestled inside the church sanctuary in place of a traditional reredos is the stone replica of the Lourdes grotto. The statue of Our Lady in white with blue sash gazes down in prayer, surrounded by flickering votive candles.",
    image: "/images/grotto.jpg",
    imageFallback: "/images/hero-church.jpg",
    imageAlt: "Grotto replica of Our Lady of Lourdes with candles and flowers",
    highlights: ["Outdoor & indoor prayer grottos", "Votive candle devotion", "Water of blessing & Rosary devotions"],
  },
  {
    id: "rosary-stained-glass",
    name: "The 15 Rosary Windows",
    subtitle: "Masterpieces of French Stained Glass",
    description:
      "High along the clerestory, fifteen magnificent stained-glass panels cast radiant jewel-toned blues, ambers, and rubies across the pews. They depict the Joyful, Sorrowful, and Glorious mysteries of the Holy Rosary.",
    image: "/images/stained-glass.jpg",
    imageFallback: "/images/hero-church.jpg",
    imageAlt: "Intricate French stained glass window depicting the Holy Rosary",
    highlights: ["15 Holy Rosary mysteries", "Crafted by French glass artisans", "Floods nave with sacred light"],
  },
  {
    id: "adoration-chapel",
    name: "Adoration Room & Spiral Staircase",
    subtitle: "Places of Contemplation & Music",
    description:
      "The quiet Adoration Room offers private daily encounter with Christ in the Blessed Sacrament (8 AM – 8 PM). Near the entrance stands a historic 19th-century cast-iron spiral staircase ascending to the choir gallery.",
    image: "/images/adoration.jpg",
    imageFallback: "/images/hero-church.jpg",
    imageAlt: "Quiet Eucharistic Adoration Chapel with golden monstrance",
    highlights: ["Daily silent adoration 8 AM – 8 PM", "1888 wrought-iron spiral staircase", "Choir loft and organ"],
  },
];

export const ministries: Ministry[] = [
  {
    id: "liturgical",
    title: "Liturgical Ministries",
    summary: "Reverent service at the altar and the proclamation of the Word of God in English and Tamil.",
    image: "/images/sanctuary.jpg",
    imageAlt: "Altar and sanctuary during liturgical celebration",
    groups: [
      {
        id: "altar-servers",
        title: "Altar Servers Society",
        tagline: "Serving Christ with reverence at the Sacred Altar",
        description:
          "Young men and boys trained in liturgical discipline and prayerful decorum, assisting priests during daily and weekend Masses and major solemnities.",
        duties: [
          "Assist the celebrant during the Holy Sacrifice of the Mass",
          "Thurifer, crucifer, and boat bearer during Solemn High Masses and Marian processions",
          "Weekly spiritual formation and liturgical training sessions",
        ],
        meetingTime: "Saturdays 3:00 PM – 4:30 PM",
      },
      {
        id: "lectors",
        title: "Ministry of Lectors & Commentators",
        tagline: "Proclaiming the Living Word of God",
        description:
          "Ministers devoted to prayerful study of the Sacred Scriptures, proclaiming the readings with clarity, reverence, and spiritual conviction in English and Tamil.",
        duties: [
          "Proclamation of the First and Second Readings and Universal Prayer",
          "Commentary and congregational guidance for solemn liturgies",
          "Monthly scriptural reflection and vocal training",
        ],
        meetingTime: "First Sunday of each month after 11:00 AM Mass",
      },
      {
        id: "choirs",
        title: "Music Ministry & Choirs",
        tagline: "Leading hearts to worship in song",
        description:
          "Multilingual choral groups leading the assembly in traditional Latin hymns, English liturgical hymns, and vibrant Tamil sacred songs accompanied by organ and instruments.",
        duties: [
          "Rehearsals and choral accompaniment for Sunday and feast day liturgies",
          "Annual Christmas and Feast of Our Lady of Lourdes cantata",
          "Novena praise and Marian choral devotions",
        ],
        meetingTime: "Fridays 7:30 PM & Saturdays 3:30 PM",
      },
      {
        id: "emhc",
        title: "Extraordinary Ministers of Holy Communion",
        tagline: "Bringing the Bread of Life to the faithful",
        description:
          "Commissioned lay ministers assisting the clergy in reverently distributing Holy Communion during Mass and taking the Blessed Sacrament to the sick.",
        duties: [
          "Distribution of the Holy Eucharist at weekend Masses",
          "Pastoral home visits to homebound parishioners and hospice patients",
          "Monthly Holy Hour and adoration vigil",
        ],
      },
    ],
  },
  {
    id: "faith-formation",
    title: "Faith Formation & RCIA",
    summary: "Guiding children, youth, and adult inquirers into deeper discipleship with Jesus Christ.",
    image: "/images/stained-glass.jpg",
    imageAlt: "Stained glass depicting Christ and the Apostles",
    groups: [
      {
        id: "rcia",
        title: "Rite of Christian Initiation of Adults (RCIA)",
        tagline: "Discover the Catholic faith and journey into full communion",
        description:
          "A year-long journey of inquiry, prayer, and Catholic catechesis for non-Catholics and baptized Christians seeking reception into the Catholic Church at Easter.",
        coordinator: "Sarah (+65 9674 5600)",
        meetingTime: "Sundays 10:00 AM – 12:00 PM (Starting May each year)",
        duties: [
          "Weekly interactive sessions on Scripture, Catholic dogma, and sacramental life",
          "One-on-one companionship with dedicated Catholic sponsors",
          "Rites of Welcoming, Election, and Sacraments of Initiation at the Easter Vigil",
        ],
      },
      {
        id: "catechism",
        title: "Children's Catechetical Ministry",
        tagline: "Nurturing young souls in the love of God",
        description:
          "Systematic Catholic faith education for children from Pre-Primary through Primary and Secondary, preparing candidates for First Reconciliation, First Communion, and Confirmation.",
        coordinator: "Verna (+65 9457 0191)",
        meetingTime: "Saturdays 4:45 PM – 5:45 PM (followed by Mass)",
        duties: [
          "Weekly classroom sessions based on archdiocesan catechetical syllabus",
          "Retreats and parent-child sacramental workshops",
          "Active integration into parish family life and community service",
        ],
      },
      {
        id: "infant-baptism",
        title: "Infant Baptism Preparation Team",
        tagline: "Welcoming the newest members of Christ's body",
        description:
          "Assisting parents and godparents in understanding the sacred responsibilities of baptism through preparatory workshops before the monthly parish baptism.",
        duties: [
          "Pre-baptism catechetical briefings for parents and godparents",
          "Preparation of liturgical materials and baptismal certificates",
          "Coordination of the monthly Sunday baptism liturgy",
        ],
      },
    ],
  },
  {
    id: "outreach",
    title: "Outreach & Migrant Care",
    summary: "Putting the Gospel into action through food, medical aid, legal support, and accompaniment.",
    image: "/images/community.jpg",
    imageAlt: "Community gathering and outreach in the church compound",
    groups: [
      {
        id: "agape-migrants",
        title: "Agape Migrant Welfare Committee",
        tagline: "Caring for South Asian migrant brothers and sisters in Singapore",
        description:
          "A landmark ministry operated under the PPC and Archdiocesan Commission for the Pastoral Care of Migrants & Itinerant People (ACMI), serving thousands of migrant workers.",
        coordinator: "Rev. Fr. Leo Justin, HGN",
        meetingTime: "Sundays following Tamil Mass",
        duties: [
          "Hot lunch and dinner distribution every Sunday after Masses",
          "Refreshments and night meals during monthly Saturday Tamil all-night vigils",
          "Free legal aid clinics, employment counselling, and hospital befriending",
          "Skills upgrading, language classes, and festive community celebrations",
        ],
      },
      {
        id: "ssvp",
        title: "Society of St. Vincent de Paul (SSVP)",
        tagline: "Seeking and finding the forgotten, the suffering, and the deprived",
        description:
          "Dedicated Vincentians visiting underprivileged families and individuals across Rochor regardless of race or religion, providing monthly grocery rations and bursaries.",
        duties: [
          "Bi-weekly home visits to Friends-in-Need (FINs) with food rations and cash assistance",
          "Educational bursaries and school supplies for low-income students",
          "Emergency medical expense support and elderly befriending",
        ],
      },
      {
        id: "legion-of-mary",
        title: "Legion of Mary",
        tagline: "Under the banner of Mary Immaculate",
        description:
          "Praesidia holding weekly prayer meetings and performing active spiritual works of mercy, including visiting the sick, praying the Rosary, and supporting families in grief.",
        meetingTime: "Weekly Praesidium meetings (English & Tamil)",
        duties: [
          "Hospital visits at Raffles, Farrer Park, and KK Hospitals",
          "Pilgrim Virgin statue home visits and family Rosary circles",
          "Spiritual support for marginalized and elderly parishioners",
        ],
      },
      {
        id: "bereavement",
        title: "Bereavement & Funeral Ministry",
        tagline: "Walking with those who mourn with the hope of the Resurrection",
        description:
          "Volunteers providing compassionate presence, vigil prayer leadership, and funeral Mass liturgical coordination for grieving families.",
        duties: [
          "Coordination of wake prayers and bereavement vigil booklets",
          "Assisting the family with funeral Mass readings, hymns, and priest scheduling",
          "Ongoing prayerful remembrance at the annual All Souls Day Masses",
        ],
      },
    ],
  },
];

export const devotions: Devotion[] = [
  {
    title: "Novena to Our Lady of Lourdes",
    when: "Every Saturday at 5:30 PM",
    where: "Main Church",
    language: "English",
    description: "Novena prayers, petition readings, Marian hymns, and blessing with the sacred Grotto water.",
  },
  {
    title: "Holy Rosary Devotion",
    when: "Weekdays 11:35 AM · Saturdays 4:15 PM · Sundays 9:00 AM",
    where: "Main Church / Outdoor Grotto",
    language: "English & Tamil",
    description: "Contemplating the mysteries of the Holy Rosary before the Holy Sacrifice of the Mass.",
  },
  {
    title: "Eucharistic Adoration in the Adoration Room",
    when: "Daily 8:00 AM – 8:00 PM",
    where: "Adoration Room (Near Main Entrance)",
    language: "Silent Contemplation",
    description: "Perpetual daily sanctuary for silent personal adoration before the exposed Blessed Sacrament.",
  },
  {
    title: "Tamil All-Night Eucharistic Vigil",
    when: "Second Saturday of every month, 9:00 PM – 5:30 AM",
    where: "Main Church",
    language: "Tamil",
    description: "All-night vigil of praise, intercessory prayers, healing service, and dawn Holy Mass.",
  },
  {
    title: "Divine Mercy Chaplet",
    when: "Tuesdays at 11:35 AM",
    where: "Main Church",
    language: "English",
    description: "Chanted chaplet of Divine Mercy imploring grace and healing for the sick and the dying.",
  },
  {
    title: "Novena to Our Lady of Perpetual Succour (OLPS)",
    when: "Every Saturday at 8:30 PM",
    where: "St. Bernadette Hall",
    language: "Tamil",
    description: "Traditional Tamil novena prayers and blessings for the Tamil-speaking community.",
  },
];

export const upcomingEvents: EventItem[] = [
  {
    id: "lourdes-feast-day",
    title: "Annual Feast Day of Our Lady of Lourdes & World Day of the Sick",
    date: "11 February 2026",
    time: "Masses throughout the day · 6:30 PM Candlelight Procession",
    summary:
      "Our premier parish feast day. Special anointing of the sick, multilingual solemn Mass, blessing with Lourdes water, and traditional outdoor candlelight Marian procession around the church grounds.",
    category: "Feast",
    venue: "Main Church & Church Compound",
    featured: true,
  },
  {
    id: "second-saturday-vigil",
    title: "Second Saturday Tamil Eucharistic Night Vigil",
    date: "Second Saturday of the Month",
    time: "9:00 PM – 5:30 AM",
    summary:
      "A night of powerful intercession, praise and worship, talks on spiritual renewal, Eucharistic adoration, and concluding dawn Tamil Holy Mass followed by breakfast provided by Agape Ministry.",
    category: "Devotion",
    venue: "Main Church",
    featured: true,
  },
  {
    id: "rcia-journey",
    title: "RCIA 2026/2027 Cohort — Come and See",
    date: "Every Sunday at 10:00 AM",
    time: "10:00 AM – 12:00 PM",
    summary:
      "Registration is now open for inquirers seeking to explore the Catholic faith or complete their initiation. Contact Sarah at +65 9674 5600 or email the parish secretariat.",
    category: "Formation",
    venue: "St. Bernadette Hall",
  },
  {
    id: "vailankanni-novena",
    title: "9-Week Novena to Our Lady of Vailankanni",
    date: "July to September Annually",
    time: "Saturdays 6:30 PM",
    summary:
      "Special nine-week spiritual preparation leading up to the Nativity of the Blessed Virgin Mary and the Feast of Our Lady of Vailankanni with multilingual floral offerings and blessing of cars.",
    category: "Devotion",
    venue: "Main Church & Shrine",
  },
  {
    id: "catechism-parents",
    title: "Catechetical Academic Year & First Sacraments",
    date: "Saturdays 4:45 PM",
    time: "4:45 PM – 5:45 PM",
    summary:
      "Classes in session for primary and secondary youth. Parents are invited to join the Saturday twilight 6:15 PM or 7:30 PM community Masses.",
    category: "Formation",
    venue: "Parish Classrooms & Hall",
  },
  {
    id: "pongal-thanksgiving",
    title: "Pongal Harvest Thanksgiving Mass",
    date: "14 January Annually",
    time: "7:00 PM",
    summary:
      "Cultural celebration of thanksgiving for God's bountiful blessings and creation, with traditional Pongal pot blessing and cultural fellowship in the church square.",
    category: "Parish",
    venue: "Main Church Courtyard",
  },
];

export const givingOptions: GivingOption[] = [
  {
    id: "paynow",
    title: "PayNow via UEN",
    subtitle: "Fast, secure electronic transfer",
    description: "Scan the QR code or enter our Unique Entity Number (UEN) directly in any Singapore mobile banking app.",
    method: "PayNow UEN",
    details: "T08CC4026D",
    icon: "globe",
    tag: "Recommended",
  },
  {
    id: "weekend-offertory",
    title: "Weekend Liturgical Offertory",
    subtitle: "During all Saturday & Sunday Masses",
    description: "Cash or envelopes placed in the collection bags during the Offertory of all weekend Masses.",
    method: "Collection Bags",
    details: "Given during Sunday Liturgy of the Eucharist",
    icon: "church",
  },
  {
    id: "cheque",
    title: "Cheque by Post or Hand",
    subtitle: "Payable to the Church",
    description: "Crossed cheques can be dropped into the donation boxes or mailed to our parish office.",
    method: "Crossed Cheque",
    details: "Make payable to: 'Church of Our Lady of Lourdes'",
    icon: "book",
  },
  {
    id: "agape-fund",
    title: "Agape Migrant Welfare Fund",
    subtitle: "Supporting weekly food distribution",
    description: "Specifically designated giving to sponsor hot Sunday meals, emergency legal support, and care packages for migrant brothers and sisters.",
    method: "PayNow (Ref: AGAPE)",
    details: "UEN: T08CC4026D (Ref: AGAPE / FOOD)",
    icon: "heart",
  },
  {
    id: "mass-intentions",
    title: "Mass Offerings & Intentions",
    subtitle: "Prayers for loved ones, the sick, or departed",
    description: "Book Mass intentions at the Parish Office during weekday hours or via the Mass intention envelopes in the church foyer.",
    method: "Parish Office Form",
    details: "Contact Parish Office: +65 6294 0624",
    icon: "flame",
  },
  {
    id: "restoration",
    title: "Heritage Conservation Fund",
    subtitle: "Preserving our 1888 National Monument",
    description: "Contributions toward the ongoing maintenance, stained-glass protection, and conservation of this sacred 136-year-old sanctuary.",
    method: "PayNow (Ref: RESTORATION)",
    details: "UEN: T08CC4026D (Ref: RESTORATION)",
    icon: "sprout",
  },
];

export const serveRoles: ServeRole[] = [
  {
    title: "Liturgical Ministers (Lectors & EMHC)",
    team: "Liturgy Committee",
    summary: "Proclaim the Word of God or assist in distributing the Holy Eucharist during weekend Masses.",
    commitment: "1–2 Masses per month + monthly spiritual formation",
    requirements: "Practicing Catholic, confirmed, in good standing with the Church.",
  },
  {
    title: "Catechists & Youth Mentors",
    team: "Catechetical Ministry",
    summary: "Teach Saturday catechism or facilitate small group faith conversations for secondary school confirmation candidates.",
    commitment: "Saturdays 4:30 PM – 6:00 PM during school terms",
    requirements: "A heart for guiding youth, background briefing and materials provided.",
  },
  {
    title: "Agape Migrant Welfare Volunteers",
    team: "Outreach & Migrant Care",
    summary: "Assist in preparing, packing, and serving Sunday hot lunches and dinners for migrant workers.",
    commitment: "Sundays (12:00 PM – 2:00 PM or 6:30 PM – 8:30 PM) on a flexible roster",
    requirements: "Open to all parishioners with willing hands and a compassionate heart.",
  },
  {
    title: "Hospitality & Wardens",
    team: "Parish Hospitality",
    summary: "Welcome worshippers at church entrances, assist with seating, and maintain a prayerful and orderly church environment.",
    commitment: "Weekend Masses of your choice (arrive 30 mins before Mass)",
    requirements: "Warm, welcoming demeanor and punctuality.",
  },
];

export const faqs: FaqItem[] = [
  {
    question: "What is the dress code for attending Mass and visiting the church?",
    answer:
      "As a sacred house of God and a consecrated Catholic sanctuary, visitors and parishioners are requested to dress modestly. Clothes that expose your knees (such as short shorts, mini skirts, and short dresses) are not allowed. Sleeveless tops, tank tops, and low-cut or see-through clothing are strongly discouraged; shoulders must remain covered during visits. Please remove hats and caps upon entering the nave.",
    category: "Visiting",
  },
  {
    question: "What languages are Masses celebrated in at Church of Our Lady of Lourdes?",
    answer:
      "We celebrate regular public liturgies in English and Tamil throughout the week. Weekday Masses are at 12:30 PM (English) and 7:00 PM (Tamil). On Sundays, we offer three English Masses (8:00 AM, 11:00 AM, 12:30 PM) and two Tamil Masses (9:30 AM and 6:30 PM). On the 1st Sunday of every month, a special Sinhala Mass is celebrated at 12:30 PM in the Sri Lankan Hall for the Sri Lankan community.",
    category: "Liturgical",
  },
  {
    question: "When is the Sacrament of Reconciliation (Confession) available?",
    answer:
      "Priests are available in the confessional 15 minutes before every weekday Mass (12:15 PM and 6:45 PM) and 15 minutes before every Saturday and Sunday Mass. You may also contact the Parish Office at +65 6294 0624 to arrange an appointment with a priest for confession or pastoral counselling.",
    category: "Sacraments",
  },
  {
    question: "How do I book a Catholic wedding (Holy Matrimony) at the church?",
    answer:
      "Weddings at the historic Church of Our Lady of Lourdes are held every Saturday at 10:00 AM and 2:00 PM only. Reservations are handled strictly on a first-come, first-served basis and must be booked at least one (1) year in advance. Please note that weddings are not held during the liturgical season of Lent (except Holy Saturday), Christmas, Days of Obligation, and Public Holidays. To submit an inquiry, email colol.secretariat@catholic.org.sg.",
    category: "Sacraments",
  },
  {
    question: "How do I register my baby for Infant Baptism?",
    answer:
      "Infant Baptisms are celebrated on scheduled Sundays. Parents must complete the Infant Baptism Application Form (downloadable or available at the Parish Office) and submit it at least two weeks before the baptism date along with the child's birth certificate, parents' Catholic marriage certificate, and godparents' baptism and confirmation certificates. At least one godparent must be a confirmed, practicing Catholic over 16 years of age.",
    category: "Sacraments",
  },
  {
    question: "How do I visit the Grotto of Massabielle and the Adoration Room?",
    answer:
      "The replica Grotto of Our Lady of Lourdes is situated inside the church sanctuary near the altar, and our outdoor shrine is accessible from the church grounds. The Adoration Room (located near the main foyer) is open daily from 8:00 AM to 8:00 PM for private prayer in silent adoration of the Blessed Sacrament. All are welcome regardless of background.",
    category: "Visiting",
  },
  {
    question: "How do I get to 50 Ophir Road by public transport, and is parking available?",
    answer:
      "The church is located right next to Bugis MRT (EW12 / DT14, 5-min walk via Exit A or B) and Rochor MRT (DT13, 6-min walk). Buses 48, 57, 130, 851, and 960 stop directly outside along Ophir Road (Stop 07589). While there are limited parking lots within the church compound for worshippers on a first-come, first-served basis, abundant public parking is located nearby at Fu Lu Shou Complex, Albert Centre, and Bugis Junction.",
    category: "Visiting",
  },
  {
    question: "How can I volunteer with the Agape Migrant Welfare Committee?",
    answer:
      "The Agape ministry welcomes volunteers of all ages to assist with food packing and distribution every Sunday afternoon and evening, translation, medical/legal assistance, and befriending. Please approach Fr. Leo Justin or contact the Parish Office at +65 6294 0624 to join this vital mission.",
    category: "Community",
  },
];
